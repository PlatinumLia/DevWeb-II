<?php
//Mostrar erros do PHP
ini_set('display_errors', 1);
error_reporting(E_ALL);

include_once(__DIR__ . "/../../controller/ArcanaController.php");
include_once(__DIR__ . "/../../controller/RacasController.php");
include_once(__DIR__ . "/../../controller/TiposController.php");
include_once(__DIR__ . "/../../util/config.php");

$arcCont = new ArcanaController();
$arcanas = $arcCont->listar();

$tiposCont = new TiposController();
$tipos = $tiposCont->listar();

$racasCont = new RacasController();
$racas = $racasCont->listar();
//print_r($racas);

include_once(__DIR__ . "/../include/header.php");
?>

<h3>Demônio</h3>

<div>
    <form method="POST" action="">
        <div>
            <label for="">Nome</label>
            <input type="text" name="nome" placeholder="Nome do demônio">
        </div>

        <div>
            <label for="">Preco</label>
            <input type="number" name="preco" placeholder="Preço do demônio">
        </div>

        <div>
            <label for="">Arcana</label>
            <select name="arcana" id="">
                <option value="">---- SELECIONE ----</option>

                <?php foreach ($arcanas as $arc) : ?>
                    <option value="<?= $arc->getId(); ?>">
                        <?= $arc->getCarta() ?>
                    </option>
                <?php endforeach; ?>

            </select>
        </div>

        <div>
            <label for="">Raça</label>
            <select name="raca" id="">
                <option value="">---- SELECIONE ----</option>

                <?php foreach ($racas as $r) : ?>
                    <option value="<?= $r->getId(); ?>">
                        <?= $r->getNome() ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div>
            <label for="">Fraqueza</label>
            <select name="fraqueza" id="">
                <option value="">---- SELECIONE ----</option>

                <?php foreach ($tipos as $t) : ?>
                    <option value="<?= $t->getId(); ?>">
                        <?= $t->getTipo() ?>
                    </option>
                <?php endforeach; ?>

            </select>
        </div>

        <div>
            <button type="submit">Gravar</button>
        </div>
    </form>
    
    <div>
        <?php if($msgErro): ?>
            <div>
                <?= $msgErro ?>
            </div>
        <?php endif; ?>
    </div>

    <div>
        <a href="listar.php">Voltar</a>
    </div>    
</div>