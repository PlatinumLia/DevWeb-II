        <!-- Footer -->
        <footer class="bg-light text-muted mt-3">
            <div class="text-center p-4">
                © 2025 Copyright:
                <a href="https://github.com/PlatinumLia"
                    target="blank">Lia</a>
            </div>
        </footer>
    </div> <!-- fecha a div criada no header -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    </body>

</html>