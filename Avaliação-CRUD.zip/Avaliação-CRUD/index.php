<?php
include_once(__DIR__ . "/view/include/header.php");

header("location:" . URL_BASE . "/view/compendium/listar.php");
?>


<?php
include_once(__DIR__ . "/view/include/footer.php");
?>